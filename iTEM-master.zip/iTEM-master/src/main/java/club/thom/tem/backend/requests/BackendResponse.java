package club.thom.tem.backend.requests;

public interface BackendResponse {
}
