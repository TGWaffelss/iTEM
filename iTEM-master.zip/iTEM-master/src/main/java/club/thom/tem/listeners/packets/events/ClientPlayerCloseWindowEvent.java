package club.thom.tem.listeners.packets.events;

import net.minecraft.network.play.client.C0DPacketCloseWindow;

public class ClientPlayerCloseWindowEvent extends PacketEvent {
    public ClientPlayerCloseWindowEvent(C0DPacketCloseWindow ignored) {}
}
